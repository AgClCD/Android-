package cn.i.teamlabel.VO;

/**
 * Created by Administrator on 2019/6/24.
 */

public class ExercisesBean {
    public int id;// 每章习题id
    public String title;// 每章习题标题
    public String content;// 每章习题的数目
    public String background;// 每章习题前边的序号背景
    public String url;// 不同的音乐文件
}
