package cn.i.teamlabel;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.List;

import cn.i.teamlabel.fragment.MyselfFragment;
import cn.i.teamlabel.fragment.minableFragment;
import cn.i.teamlabel.fragment.teamFragment;
import cn.i.teamlabel.fragment.timeFragment;

public class MainmenuActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageButton menu_time;
    private ImageButton menu_mine;
    private ImageButton menu_teamlable;
    private ImageButton menu_minelable;
    //private int index;
    private ViewPager vp;
    private TextView menu_tv_mylable, menu_tv_teamlable, menu_tv_timelable, menu_tv_mine;
    private List<Fragment> fragmentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainmenu);
        view();

        List<Fragment> fragments = new ArrayList<Fragment>();
        fragments.add(new minableFragment());
        fragments.add(new teamFragment());
        fragments.add(new timeFragment());
        fragments.add(new MyselfFragment());

        FragAdapter adapter = new FragAdapter(getSupportFragmentManager(), fragments);

        //设定适配器
        vp = findViewById(R.id.vp_mainmenu);
        vp.setOffscreenPageLimit(4);
        vp.setAdapter(adapter);
        clearImageButton();
        setSelectedStatus(3);
        vp.setCurrentItem(3);

        vp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int index) {
                clearImageButton();
                setSelectedStatus(index);
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
    }

    public void view() {
        menu_time = findViewById(R.id.menu_time);
        menu_mine = findViewById(R.id.menu_mine);
        menu_teamlable = findViewById(R.id.menu_teamlable);
        menu_minelable = findViewById(R.id.menu_minelable);
        menu_tv_mylable = findViewById(R.id.menu_tv_mylable);
        menu_tv_teamlable = findViewById(R.id.menu_tv_teamlable);
        menu_tv_timelable = findViewById(R.id.menu_tv_timelable);
        menu_tv_mine = findViewById(R.id.menu_tv_mine);


        menu_teamlable.setOnClickListener(this);
        menu_mine.setOnClickListener(this);
        menu_time.setOnClickListener(this);
        menu_minelable.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case (R.id.menu_minelable):
                clearImageButton();
                setSelectedStatus(0);
                vp.setCurrentItem(0,true);
                break;
            case (R.id.menu_teamlable):
                clearImageButton();
                setSelectedStatus(1);
                vp.setCurrentItem(1,true);
                break;
            case (R.id.menu_time):
                clearImageButton();
                setSelectedStatus(2);
                vp.setCurrentItem(2,true);
                break;
            case (R.id.menu_mine):
                clearImageButton();
                setSelectedStatus(3);
                vp.setCurrentItem(3,true);
                break;
        }
    }

    private void clearImageButton() {
        menu_minelable.setBackgroundResource(R.drawable.pen);
        menu_teamlable.setBackgroundResource(R.drawable.mulu);
        menu_time.setBackgroundResource(R.drawable.ziyuanshijian);
        menu_mine.setBackgroundResource(R.drawable.ziyuan_geren);
        menu_time.setSelected(false);
        menu_mine.setSelected(false);
        menu_teamlable.setSelected(false);
        menu_minelable.setSelected(false);
    }

    private void setSelectedStatus(int index) {

        switch (index) {
            case 0:
                menu_minelable.setSelected(true);
                menu_minelable.setBackgroundResource(R.drawable.pen2);
                break;
            case 1:
                menu_teamlable.setSelected(true);
                menu_teamlable.setBackgroundResource(R.drawable.team1);
                break;
            case 2:
                menu_time.setSelected(true);
                menu_time.setBackgroundResource(R.drawable.shijian);
                break;
            case 3:
                menu_mine.setSelected(true);
                menu_mine.setBackgroundResource(R.drawable.my);
                break;
        }
    }

    public class FragAdapter extends FragmentPagerAdapter {

        public FragAdapter(FragmentManager fm, List<Fragment> fragments) {
            super(fm);
            fragmentList = fragments;
        }

        @Override
        public Fragment getItem(int index) {
            return fragmentList.get(index);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }
    }
}
