//package cn.i.teamlabel.Musicset;
//
//import android.app.Service;
//import android.content.Intent;
//import android.media.MediaPlayer;
//import android.os.Binder;
//import android.os.IBinder;
//
//public class MusicService extends Service {
//    private static  final String TAG="MusicService";
//    public MediaPlayer mediaPlay;
//    class MyBinder extends Binder{
//        public void play(String path){
//
//        }
//    }
//    @Override
//    public IBinder onBind(Intent intent) {
//        return null;
//    }
//}
