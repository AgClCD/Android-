package cn.i.teamlabel;

import android.content.Intent;
import android.net.http.SslError;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebActivity extends AppCompatActivity {
    private WebView wvExercises;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        wvExercises = findViewById(R.id.wv);
        Intent intent = getIntent();
        String uri = intent.getStringExtra("uri");

        if(wvExercises!=null){
            wvExercises.setWebViewClient(new WebViewClient(){
                @Override
                public void onReceivedSslError(WebView view,
                                               SslErrorHandler handler, SslError error){
                    handler.proceed();
                }
            });
            wvExercises.loadUrl(uri);
        }
    }
}
