package cn.i.teamlabel.Musicset;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;

import java.io.InputStream;
import java.util.List;

import cn.i.teamlabel.R;
import cn.i.teamlabel.VO.ExercisesBean;
import cn.i.teamlabel.Adapter.ExercisesListAdapter;
import cn.i.teamlabel.util.JsonUtil;

public class BGMActivity extends AppCompatActivity implements View.OnClickListener {
    private ListView lv_list;
    private ExercisesListAdapter adapter;
    private List<ExercisesBean>eb1;
    private ImageButton bgm_close;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bgm);
        bgm_close=findViewById(R.id.bgm_close);
        bgm_close.setOnClickListener(this);
        InputStream is = getResources().openRawResource(R.raw.exercises);
        List<ExercisesBean>exercisesBeanList=null;
        try {
            exercisesBeanList = JsonUtil.getExerciseInfosFromJson(is);
            lv_list = findViewById(R.id.lv_list);
            adapter = new ExercisesListAdapter(BGMActivity.this,exercisesBeanList) {
            };
            lv_list.setAdapter(adapter);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()) {
            case R.id.bgm_close:
                BGMActivity.this.finish();
                break;
        }
    }
}
