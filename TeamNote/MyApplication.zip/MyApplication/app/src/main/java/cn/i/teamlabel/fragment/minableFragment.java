package cn.i.teamlabel.fragment;



import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import cn.i.teamlabel.R;
import cn.i.teamlabel.mainlable.EditActivity;

import static android.content.Context.MODE_PRIVATE;
//import cn.i.teamlabel.mainlable.MainlableActivity;

public class minableFragment extends Fragment implements View.OnClickListener{
//    private ListView mine_list_view;
    private ImageButton mainmenu_add;
    private TextView list_item_title,list_item_body;
    private LinearLayout list_L1;

        public minableFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_minable, container, false);
        mainmenu_add = view.findViewById(R.id.mainmenu_add);
        list_L1 = view.findViewById(R.id.list_L1);
        list_item_title = view.findViewById(R.id.list_item_title);
        list_item_body= view.findViewById(R.id.list_item_body);

        mainmenu_add.setOnClickListener(this);
        list_L1.setOnClickListener(this);
        initText();

//        mine_list_view = view.findViewById(R.id.mine_list_view);
return view;
    }

    @Override
    public void onClick(View v) {
            switch (v.getId()){
                case R.id.mainmenu_add:
                    Intent intent=new Intent(getActivity(), EditActivity.class);
                    startActivity(intent);
                    break;
                case R.id.list_L1:
                    Intent intent1=new Intent(getActivity(), EditActivity.class);
                    startActivity(intent1);
                    break;
            }


    }
    public void initText() {
        // 读取本地存储中有没有输入的用户名
        SharedPreferences sp = getActivity().getSharedPreferences("loginInfo", MODE_PRIVATE);
        String result3 = sp.getString("title", "");
        String result4 = sp.getString("body", "");
        list_item_body.setText(result4);
        list_item_title.setText("标题："+result3);
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data!=null){
            initText();
        }
    }
//
//    @Override
//    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//    }
//
//    @Override
//    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
//        return false;
//    }
}

