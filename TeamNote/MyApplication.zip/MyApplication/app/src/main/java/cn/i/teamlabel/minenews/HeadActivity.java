package cn.i.teamlabel.minenews;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import cn.i.teamlabel.R;

@SuppressLint("SdCardPath")
public class HeadActivity extends AppCompatActivity implements View.OnClickListener {
    private Button head_bt_photo;
    private ImageButton head_bt_fh;
    private ImageView head_Im_head;
    private Bitmap head;
    private static String path="/sdcard/myhead/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_head);
        intView();
    }
    private void intView(){
        head_bt_fh=findViewById(R.id.head_bt_fh);
//        head_bt_takephoto=findViewById(R.id.head_bt_takephoto);
        head_bt_photo=findViewById(R.id.head_bt_photo);
        head_Im_head=findViewById(R.id.head_Im_head);
        head_bt_fh.setOnClickListener(this);
        head_bt_photo.setOnClickListener(this);
//        head_bt_takephoto.setOnClickListener(this);
        Bitmap bt=BitmapFactory.decodeFile(path+"head.jpg");
        if (bt!=null){
            @SuppressWarnings("deprecation")
            Drawable drawable=new BitmapDrawable(bt);//转换成drawable
            head_Im_head.setImageDrawable(drawable);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.head_bt_fh:
                HeadActivity.this.finish();
                break;
            case R.id.head_bt_photo:
                Intent intent1=new Intent(Intent.ACTION_PICK,null);
                intent1.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/*");
                startActivityForResult(intent1,1);
                break;
//            case R.id.head_bt_takephoto:
//                ActivityCompat.requestPermissions(new HeadActivity(),new String[]{
//                        Manifest.permission.CAMERA,Manifest.permission.
//                        WRITE_EXTERNAL_STORAGE},1);//适配安卓6.0版本上的相机权限需添加的权限
//                Intent intent2=new Intent((MediaStore.ACTION_IMAGE_CAPTURE));
//                intent2.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(Environment.
//                        getExternalStorageDirectory(),"head.jpg")));
//                startActivityForResult(intent2,2);
//                break;
                default:
                    break;
        }
    }protected void  onActivityResult(int requestCode,int resultCode,Intent data){
        switch (requestCode){
            case 1:
                if(resultCode==RESULT_OK){
                    cropPhoto(data.getData());
                }
                break;
            case 2:
                if(resultCode==RESULT_OK){
                    File temp=new File(Environment.getExternalStorageDirectory()
                    +"/head.jpg");
                    cropPhoto(Uri.fromFile(temp));
                }
                break;
            case 3:
                if (data!=null){
                    Bundle extras=data.getExtras();
                    assert extras != null;
                    head=extras.getParcelable("data");
                    if (head!=null){
                        setPicToView(head);
                        head_Im_head.setImageBitmap(head);
                    }
                }
                break;
                default:
                    break;
        }
        super.onActivityResult(requestCode,resultCode,data);
    }

    private void cropPhoto(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", 150);
        intent.putExtra("outputY", 150);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, 3);
    }
    private void setPicToView(Bitmap bitmap) {
        String sdStatus=Environment.getExternalStorageState();
        if (!sdStatus.equals(Environment.MEDIA_MOUNTED)){
            return;
        }
        FileOutputStream b=null;
        File file=new File(path);
        file.mkdirs();
        String fileName=path+"head.jpg";
        try{
            b=new FileOutputStream(fileName);
            bitmap.compress(Bitmap.CompressFormat.JPEG,100,b);
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }finally {
            try{
                b.flush();
                b.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }
}
