package cn.i.teamlabel.fragment;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import cn.i.teamlabel.Aboutus.AboutusActivity;
import cn.i.teamlabel.MainActivity;
import cn.i.teamlabel.Musicset.BGMActivity;
import cn.i.teamlabel.RegisteActivity;
import cn.i.teamlabel.backgroundset.BackgroundsetActivity;
import cn.i.teamlabel.minenews.MinenewsActivity;
import cn.i.teamlabel.R;
import cn.i.teamlabel.minenews.SetnameActivity;

import static android.content.Context.MODE_PRIVATE;

/**
 * A simple {@link Fragment} subclass.
 */
public class MyselfFragment extends Fragment {
    private LinearLayout menu_f_my_L1,f_my_L2,f_my_L3,f_my_L4,f_my_L5;
    private TextView f_my_TV_username,f_my_TV_id;
    private ImageView f_my_IV_tx;
    public MyselfFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_myself, container, false);
        f_my_L2=view.findViewById(R.id.f_my_L2);
        f_my_IV_tx=view.findViewById(R.id.f_my_IV_tx);
        menu_f_my_L1=view.findViewById(R.id.menu_f_my_L1);
        f_my_TV_id=view.findViewById(R.id.f_my_TV_id);
        f_my_L3=view.findViewById(R.id.f_my_L3);
        f_my_L4=view.findViewById(R.id.f_my_L4);
        f_my_L5=view.findViewById(R.id.f_my_L5);
        f_my_TV_username=view.findViewById(R.id.f_my_TV_username);

        initTextView();
        changename();

        f_my_IV_tx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        f_my_L2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(), MinenewsActivity.class);
                startActivity(intent);
            }
        });
        f_my_L3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),BGMActivity.class);
                startActivity(intent);
            }
        });
        f_my_L4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),BackgroundsetActivity.class);
                startActivity(intent);

            }
        });
        f_my_L5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(), AboutusActivity.class);
                startActivity(intent);
            }
        });
        return view;
    }
    public void initTextView() {
        // 读取本地存储中有没有输入的用户名
        SharedPreferences sp = getActivity().getSharedPreferences("loginInfo", MODE_PRIVATE);
        String result = sp.getString("loginID", "");
        f_my_TV_id.setText("ID:  "+result);
    }
    public void changename(){
        SharedPreferences sp = getActivity().getSharedPreferences("loginInfo", MODE_PRIVATE);
        String result1 = sp.getString("name", "");
        f_my_TV_username.setText(result1);
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data!=null){
            initTextView();
        }
    }
}
