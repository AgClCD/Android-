package cn.i.teamlabel;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity implements TextView.OnClickListener{
    private TextView tv_1;
    private TextView tv_2;
    private TextView tv_3;
    private TextView tv_4;
    private TextView tv;
    private int recLen = 5;;
    Timer timer = new Timer();
    private Handler handler;
    private Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        tv_1 = findViewById(R.id.tv_1);
        tv_2 = findViewById(R.id.tv_2);
        tv_3 = findViewById(R.id.tv_3);
        tv_4 = findViewById(R.id.tv_4);
        tv= findViewById(R.id.tv);
        int flag= WindowManager.LayoutParams.FLAG_FULLSCREEN;
        getWindow().setFlags(flag,flag);
        tv_1.setTypeface(Typeface.createFromAsset(getAssets(), "font/kkkti.ttf"));
        tv_2.setTypeface(Typeface.createFromAsset(getAssets(), "font/lllye.ttf"));
        tv_3.setTypeface(Typeface.createFromAsset(getAssets(), "font/kkkti.ttf"));
        tv_4.setTypeface(Typeface.createFromAsset(getAssets(), "font/Inkfree.ttf"));
        intitView();
        timer.schedule(task,1000,1000);
        handler=new Handler();
        handler.postDelayed(runnable=new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(SplashActivity.this,MainmenuActivity.class);
                startActivity(intent);
                finish();
            }
        },3000);
    }
    private void intitView(){
        tv.setOnClickListener(this);
    }
    TimerTask task=new TimerTask() {
        @Override
        public void run() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tv.setTypeface(Typeface.createFromAsset(getAssets(), "font/kkkti.ttf"));
                    recLen--;
                    tv.setText("跳过"+recLen);
                    if(recLen<0){
                        timer.cancel();
                        tv.setVisibility(View.GONE);
                    }
                }
            });
        }
    };
    public void onClick(View view){
        switch (view.getId()){
            case R.id.tv:
                Intent intent=new Intent(SplashActivity.this,MainmenuActivity.class);
                startActivity(intent);
                finish();
                if (runnable !=null){
                    handler.removeCallbacks(runnable);
                }
                break;
                default:
                    break;
        }
    }
}
