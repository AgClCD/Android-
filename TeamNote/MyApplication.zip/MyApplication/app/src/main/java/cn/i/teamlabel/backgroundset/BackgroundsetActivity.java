package cn.i.teamlabel.backgroundset;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import cn.i.teamlabel.R;

public class BackgroundsetActivity extends AppCompatActivity {
    private TextView Bg_tv_1,Bg_tv_2;
    private ImageButton Bg_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_backgroundset);
        Bg_tv_1=findViewById(R.id.Bg_tv_1);
        Bg_tv_2=findViewById(R.id.Bg_tv_2);
        Bg_back=findViewById(R.id.Bg_back);
        Bg_tv_1.setTypeface(Typeface.createFromAsset(getAssets(), "font/kkkti.ttf"));
        Bg_tv_2.setTypeface(Typeface.createFromAsset(getAssets(), "font/lllye.ttf"));
        Bg_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BackgroundsetActivity.this.finish();
            }
        });
    }
}
