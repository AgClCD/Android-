package cn.i.teamlabel;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import cn.i.teamlabel.minenews.MinenewsActivity;


public class MainActivity extends AppCompatActivity {
    private TextView main_tv_1,main_tv_2;
    private Button main_bt_2,main_singon,main_bt_forgetpass;
    private EditText main_et_username,main_et_pass;
    public Intent intent;
    private ImageButton main_back,main_close;
   private String username,psw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        main_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.finish();
            }
        });
        main_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.finish();
            }
        });
        main_bt_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,RegisteActivity.class);
                startActivity(intent);
            }
        });
        main_bt_forgetpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        main_singon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username=main_et_username.getText().toString().trim();
                psw=main_et_pass.getText().toString().trim();
                if (TextUtils.isEmpty(username)) {
                    Toast.makeText(MainActivity.this, "请输入用户名", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(psw)) {
                    Toast.makeText(MainActivity.this, "请输入密码", Toast.LENGTH_SHORT).show();
                    return;
                }

                // 读取本地存储中有没有输入的用户名
                SharedPreferences sp = getSharedPreferences("loginInfo", MODE_PRIVATE);
                String result = sp.getString(username, "");

                if (result.equals("")) {
                    Toast.makeText(MainActivity.this, "无此用户", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (result.equals(psw)) {
                    // 登录成功后，把用户名记录下来，以后就不用登录了
                    SharedPreferences.Editor editor=sp.edit();
                    editor.putString("loginID", username);
                    editor.commit();
                    //把登录信息告诉我的页面
                    Intent data=new Intent();
                    data.putExtra("loginID",username);
                    setResult(RESULT_OK,data);
                    Intent intent=new Intent(MainActivity.this, MinenewsActivity.class);
                    startActivity(intent);
                    MainActivity.this.finish();
                    Toast.makeText(MainActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "密码错误", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void init() {
        main_tv_1=findViewById(R.id.main_tv_1);
        main_tv_2=findViewById(R.id.main_tv_2);
        main_bt_2=findViewById(R.id.main_bt_2);
        main_bt_2=findViewById(R.id.main_bt_2);
        main_back=findViewById(R.id.main_back);
        main_singon=findViewById(R.id.main_singon);
        main_close=findViewById(R.id.main_close);
        main_bt_forgetpass=findViewById(R.id.main_bt_forgetpass);
        main_et_username=findViewById(R.id.main_et_username);
        main_et_pass=findViewById(R.id.main_et_pass);


        main_tv_1.setTypeface(Typeface.createFromAsset(getAssets(),"font/kkkti.ttf"));
        main_tv_2.setTypeface(Typeface.createFromAsset(getAssets(),"font/kkkti.ttf"));
    }



}
