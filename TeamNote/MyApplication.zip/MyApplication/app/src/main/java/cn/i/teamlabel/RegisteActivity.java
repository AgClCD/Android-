package cn.i.teamlabel;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


public class RegisteActivity extends AppCompatActivity {
    private TextView R_tv_1, R_tv_2;
    private Button R_bt_1;
    private EditText R_et_1, R_et_2, R_et_3;
    private ImageButton rs_back, rs_close;
    private String userName, psw, pswAgain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registe);
        init();
        rs_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisteActivity.this.finish();
            }
        });
        rs_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisteActivity.this.finish();
            }
        });
        R_bt_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userName = R_et_1.getText().toString().trim();
                psw = R_et_2.getText().toString().trim();
                pswAgain = R_et_3.getText().toString().trim();

                if (TextUtils.isEmpty(userName)) {
                    Toast.makeText(RegisteActivity.this, "请输入用户名", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(psw)) {
                    Toast.makeText(RegisteActivity.this, "请输入密码", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(pswAgain)) {
                    Toast.makeText(RegisteActivity.this, "请再次输入密码", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!psw.equals(pswAgain)) {
                    Toast.makeText(RegisteActivity.this, "输入两次的密码不一样", Toast.LENGTH_SHORT).show();
                    return;
                }
                // 保存操作
                // 打开存储的文件
                SharedPreferences sp = getSharedPreferences("loginInfo", MODE_PRIVATE);
                // 打开编辑器
                SharedPreferences.Editor editor = sp.edit();

                String result = sp.getString(userName, "");

                if (result.equals("")) {
                    // 写入数据
                    editor.putString(userName, psw);
                    // 提交保存
                    editor.commit();
                    Toast.makeText(RegisteActivity.this, "注册成功", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(RegisteActivity.this,MainActivity.class);
                    startActivity(intent);
                    RegisteActivity.this.finish();
                } else {
                    Toast.makeText(RegisteActivity.this, "用户已经存在", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void init() {
        R_tv_1 = findViewById(R.id.R_tv_1);
        R_tv_2 = findViewById(R.id.R_tv_2);
        R_bt_1 = findViewById(R.id.R_bt_1);
        R_et_1 = findViewById(R.id.R_et_1);
        R_et_2 = findViewById(R.id.R_et_2);
        R_et_3 = findViewById(R.id.R_et_3);
        rs_back = findViewById(R.id.rs_back);
        rs_close = findViewById(R.id.rs_close);

        R_tv_1.setTypeface(Typeface.createFromAsset(getAssets(), "font/kkkti.ttf"));
        R_tv_2.setTypeface(Typeface.createFromAsset(getAssets(), "font/kkkti.ttf"));
    }


}