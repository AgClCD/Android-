package cn.i.teamlabel.fragment;



import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import cn.i.teamlabel.Adapter.CourseListAdapter;
import cn.i.teamlabel.R;
import cn.i.teamlabel.VO.CourseBean;
import cn.i.teamlabel.util.JsonUtil;

/**
 * A simple {@link Fragment} subclass.
 */
public class teamFragment extends Fragment {
    private ListView lv_list;
    private CourseListAdapter adapter;
    private List<List<CourseBean>> cbl = new ArrayList<>();
    private List<Fragment> fragmentList;
    private ViewPager vp;


    public teamFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_team, container, false);
        InputStream is = getActivity().getResources().openRawResource(R.raw.courses);
        List<CourseBean> courseBeans = null;
        try {
            courseBeans = JsonUtil.getCourseInfosFromJson(is);
            List<CourseBean> tempBeans = new ArrayList<>();

            int count = 0;
            for (int i = 0; i < courseBeans.size(); i++) {
                CourseBean bean = courseBeans.get(i);
                count++;
                tempBeans.add(bean);
                if (count % 2 == 0) {// 课程界面每两个数据是一组放在List集合中
                    cbl.add(tempBeans);
                    tempBeans = null;
                    tempBeans = new ArrayList<>();
                }
            }

            lv_list = view.findViewById(R.id.lv_course_list);
            adapter = new CourseListAdapter(getActivity(), cbl);
            lv_list.setAdapter(adapter);
        } catch (Exception e) {

        }
        List<Fragment> fragments = new ArrayList<Fragment>();
        fragments.add(new Banner1Fragment());
        fragments.add(new Banner2Fragment());
        fragments.add(new Banner3Fragment());

        FragAdapter adapter = new FragAdapter(getActivity().getSupportFragmentManager(), fragments);
        vp = view.findViewById(R.id.vp_banner);
        vp.setAdapter(adapter);
        handler.sendEmptyMessageDelayed(1, 3000);
        return view;
    }
    public class FragAdapter extends FragmentStatePagerAdapter {
        public FragAdapter(FragmentManager fm, List<Fragment> fragments) {
            super(fm);
            fragmentList = fragments;
        }

        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }
    }
    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                if (vp != null) {
                    if (vp.getCurrentItem() == vp.getChildCount()) {
                        vp.setCurrentItem(0);
                    } else {
                        vp.setCurrentItem(vp.getCurrentItem() + 1);
                    }
                }

                handler.sendEmptyMessageDelayed(1, 3000);
            }
        }
    };
}
