package cn.i.teamlabel.VO;

public class CourseBean {
    public int id;            //每章节id
    public String imgTitle;  //图片上的标题
    public String title;     //章节标题
    public String icon;      //广告栏上的图片
    public String uri;//网页地址
}