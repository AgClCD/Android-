package cn.i.teamlabel.Musicset;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import java.io.IOException;

import cn.i.teamlabel.R;

public class MusicplayActivity extends AppCompatActivity implements View.OnClickListener {

    private Button tv_play,tv_pause;
    private TextView m_tv2;
    private ImageButton music_close;
    public VideoView mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_musicplay);
        Intent intent = getIntent();
        String ur1 = intent.getStringExtra("ur1");
        String title = intent.getStringExtra("title");


        music_close = findViewById(R.id.music_close);
        tv_play = findViewById(R.id.tv_play);
        tv_pause = findViewById(R.id.tv_pause);
        mediaPlayer= findViewById(R.id.mediaPlay);

        tv_play.setOnClickListener(this);
        tv_pause.setOnClickListener(this);
        music_close.setOnClickListener(this);
        m_tv2 = findViewById(R.id.m_tv2);
        m_tv2.setText(title);
//        ActionBar actionBar=getSupportActionBar();
//        actionBar.setTitle(title);
//        actionBar.setDisplayHomeAsUpEnabled(true);

        String uri = "android.resource://" + getPackageName() + "/" + R.raw.m7;
        mediaPlayer.setVideoPath(uri);
        MediaController controller=new MediaController(this);
        mediaPlayer.setMediaController(controller);
        mediaPlayer.start();

//        try{
//            if(mediaPlayer==null){
//                mediaPlayer=new MediaPlayer();
//                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
//                mediaPlayer.setDataSource(uri);
//                mediaPlayer.prepare();
//                mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
//                    @Override
//                    public void onPrepared(MediaPlayer mp) {
//                        mediaPlayer.start();
//                    }
//                });
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return  true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.music_close:
                MusicplayActivity.this.finish();
        }

    }
}
