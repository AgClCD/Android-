package cn.i.teamlabel.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.i.teamlabel.R;
import cn.i.teamlabel.VO.WeatherInfo;
import cn.i.teamlabel.VO.WeatherService;

/**
 * A simple {@link Fragment} subclass.
 */
public class timeFragment extends Fragment implements View.OnClickListener{
    private Button btn_jz,btn_sh,btn_bj;
    private TextView tv_city;
    private TextView tv_weather;
    private TextView tv_temp;
    private TextView tv_wind;
    private TextView tv_pm;
    private ImageView iv_icon;
    private ArrayList<Map<String, String>> list;
    private Map<String,String>map;
    private String temp,weather,name,pm,wind;


    public timeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_time, container, false);

        btn_jz=view.findViewById(R.id.btn_jz);
        btn_bj=view.findViewById(R.id.btn_bj);
        btn_sh=view.findViewById(R.id.btn_sh);
        tv_city=view.findViewById(R.id.tv_city);
        tv_weather=view.findViewById(R.id.tv_weather);
        tv_temp=view.findViewById(R.id.tv_temp);
        tv_wind=view.findViewById(R.id.tv_wind);
        tv_pm=view.findViewById(R.id.tv_pm);
        iv_icon=view.findViewById(R.id.iv_icon);

        btn_bj.setOnClickListener(this);
        btn_jz.setOnClickListener(this);
        btn_sh.setOnClickListener(this);

        try{
            InputStream is=this.getResources().openRawResource(R.raw.weather1);
            List<WeatherInfo>weatherInfos= WeatherService.getInfosFromXML(is);
            list=new ArrayList<Map<String,String>>();
            for (WeatherInfo info:weatherInfos){
                map=new HashMap<String,String>();
                map.put("temp",info.getTemp());
                map.put("weather",info.getWeather());
                map.put("name",info.getName());
                map.put("pm",info.getPm());
                map.put("wind",info.getWind());
                list.add(map);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        getMap(1,R.drawable.duoyun);
        return view;
    }
        public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_jz:
                getMap(0,R.drawable.taiy );
                break;
            case R.id.btn_sh:
                getMap(1,R.drawable.duoyun);
                break;
            case R.id.btn_bj:
                getMap(2,R.drawable.xiaoyu);
                break;
        }

    }

    private void getMap(int number, int iconNumber) {
        Map<String,String>cityMap=list.get(number);
        temp=cityMap.get("temp");
        weather=cityMap.get("weather");
        name=cityMap.get("name");
        pm=cityMap.get("pm");
        wind=cityMap.get("wind");
        tv_city.setText(name);
        tv_temp.setText(temp);
        tv_weather.setText(weather);
        tv_wind.setText("风力 "+wind);
        tv_pm.setText("pm "+pm);
        iv_icon.setImageResource(iconNumber
        );
    }
}
