package cn.i.teamlabel.VO;

import android.content.Context;

import java.io.FileOutputStream;

public class Filesaveusername {
    public static boolean saveUserInfo(Context context,String name){
        try{
            FileOutputStream fos=context.openFileOutput("data1.txt",Context.
                    MODE_PRIVATE);
            fos.write((name).getBytes());
            fos.close();
            return true;
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }
}
