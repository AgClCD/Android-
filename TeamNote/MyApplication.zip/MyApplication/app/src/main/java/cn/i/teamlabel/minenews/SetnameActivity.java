package cn.i.teamlabel.minenews;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import cn.i.teamlabel.MainActivity;
import cn.i.teamlabel.R;
import cn.i.teamlabel.fragment.MyselfFragment;

public class SetnameActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageButton setname_close;
    private Button name_bt;
    private EditText name_et;
    private  String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setname);
        setname_close=findViewById(R.id.setname_close);
        name_bt=findViewById(R.id.name_bt);
        name_et=findViewById(R.id.name_et);

        setname_close.setOnClickListener(this);
        name_bt.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
//        Intent intent=new Intent();
        switch (v.getId()){
            case R.id.setname_close:
                SetnameActivity.this.finish();
            case R.id.name_bt:
//                intent.putExtra("name",nameInfo);
                passDate();
        }

    }
    public void passDate(){
        name=name_et.getText().toString().trim();
        if(TextUtils.isEmpty(name)){
            Toast.makeText(SetnameActivity.this,"请输入昵称",Toast.LENGTH_SHORT).show();
            return;
        }
        SharedPreferences sp = getSharedPreferences("loginInfo", MODE_PRIVATE);
        String result1 = sp.getString(name, "");

        if (result1.equals("")) {
            // 登录成功后，把用户名记录下来，以后就不用登录了
            SharedPreferences.Editor editor=sp.edit();
            editor.putString("name", name);
            editor.commit();
            //把登录信息告诉我的页面
            Intent data=new Intent();
            data.putExtra("name",name);
            setResult(RESULT_OK,data);
            Intent intent=new Intent(SetnameActivity.this,MinenewsActivity.class);
            startActivity(intent);
            SetnameActivity.this.finish();
        }else{
            Toast.makeText(SetnameActivity.this,"昵称已存在",Toast.LENGTH_SHORT).show();

        }
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
