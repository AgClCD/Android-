package cn.i.teamlabel.minenews;

import android.app.job.JobInfo;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import cn.i.teamlabel.MainActivity;
import cn.i.teamlabel.MainmenuActivity;
import cn.i.teamlabel.R;
import cn.i.teamlabel.RegisteActivity;

public class MinenewsActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageButton minenews_bt_fh, minenews_IB_tx;
    private RelativeLayout minenews_R5, minenews_R2,minenews_R3,minenews_R6 ;
    private TextView minenews_T_name,minenews_T_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_minenews);
        Minenews();
        changename();
        changeid();

    }

    private void Minenews() {
        minenews_bt_fh = findViewById(R.id.minenews_bt_fh);
        minenews_IB_tx = findViewById(R.id.minenews_IB_tx);
        minenews_T_name=findViewById(R.id.minenews_T_name);
        minenews_T_id=findViewById(R.id.minenews_T_id);
        minenews_R5 = findViewById(R.id.minenews_R5);
        minenews_R2 = findViewById(R.id.minenews_R2);
        minenews_R3 = findViewById(R.id.minenews_R3);
        minenews_R6 = findViewById(R.id.minenews_R6);

        minenews_bt_fh.setOnClickListener(this);
        minenews_R6.setOnClickListener(this);
        minenews_R2.setOnClickListener(this);
        minenews_R3.setOnClickListener(this);
        minenews_R5.setOnClickListener(this);

    }
    private void changename(){
        SharedPreferences sp = getSharedPreferences("loginInfo",MODE_PRIVATE);
        String result1= sp.getString("name", "");
        if(result1.equals("")){
            minenews_T_name.setText("设置昵称");
        }else {
            minenews_T_name.setText(result1);
        }


    }
    private void changeid(){
        SharedPreferences sp = getSharedPreferences("loginInfo",MODE_PRIVATE);
        String result= sp.getString("loginID", "");
            minenews_T_id.setText(result);
    }


    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()) {
            case R.id.minenews_bt_fh:
                intent=new Intent(MinenewsActivity.this, MainmenuActivity.class);
                startActivity(intent);
                MinenewsActivity.this.finish();
                break;
            case R.id.minenews_R2:
                intent = new Intent(MinenewsActivity.this, HeadActivity.class);
                startActivity(intent);
                break;
            case R.id.minenews_R3:
                intent = new Intent(MinenewsActivity.this, SetnameActivity.class);
                startActivity(intent);
                break;
            case R.id.minenews_R5:
                intent = new Intent(MinenewsActivity.this, ErweimaActivity.class);
                startActivity(intent);
                break;
            case R.id.minenews_R6:
                intent=new Intent(MinenewsActivity.this, MainActivity.class);
                startActivityForResult(intent,0);
        }
    }

}

