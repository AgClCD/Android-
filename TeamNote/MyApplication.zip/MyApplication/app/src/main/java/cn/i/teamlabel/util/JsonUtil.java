package cn.i.teamlabel.util;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.List;

import cn.i.teamlabel.VO.CourseBean;
import cn.i.teamlabel.VO.ExercisesBean;

public class JsonUtil {

    public static List<ExercisesBean> getExerciseInfosFromJson(InputStream is) throws IOException {
        byte[] buffer = new byte[is.available()];
        is.read(buffer);
        String json = new String(buffer, "utf-8");
        Gson gson = new Gson();
        Type listType = new TypeToken<List<ExercisesBean>>() {
        }.getType();
        List<ExercisesBean> exercisesBeanList = gson.fromJson(json, listType);

        return exercisesBeanList;
    }

    public static List<CourseBean> getCourseInfosFromJson(InputStream is) throws IOException {
        byte[] buffer = new byte[is.available()];
        is.read(buffer);
        String json = new String(buffer, "utf-8");
        Gson gson = new Gson();
        Type listType = new TypeToken<List<CourseBean>>() {
        }.getType();
        List<CourseBean> courseBeanList = gson.fromJson(json, listType);

        return courseBeanList;
    }

}
