package cn.i.teamlabel.Aboutus;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import cn.i.teamlabel.R;

public class AboutusActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageButton a_back;
    private VideoView a_V;
    private TextView a_tv_1,a_tv_2,a_tv_3,a_tv_4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aboutus);
        a_back=findViewById(R.id.a_back);
        a_tv_1=findViewById(R.id.a_tv_1);
        a_tv_2=findViewById(R.id.a_tv_2);
        a_tv_3=findViewById(R.id.a_tv_3);
        a_tv_4=findViewById(R.id.a_tv_4);
        a_tv_1.setTypeface(Typeface.createFromAsset(getAssets(), "font/kkkti.ttf"));
        a_tv_2.setTypeface(Typeface.createFromAsset(getAssets(), "font/lllye.ttf"));
        a_tv_3.setTypeface(Typeface.createFromAsset(getAssets(), "font/kkkti.ttf"));
        a_tv_4.setTypeface(Typeface.createFromAsset(getAssets(), "font/lllye.ttf"));
        a_V=findViewById(R.id.a_V);
        a_back.setOnClickListener(this);
        String uri = "android.resource://" + getPackageName() + "/" +R.raw.xiaoying;
        MediaController controller=new MediaController(this);
        a_V.setVideoPath(uri);
        a_V.start();
    }

    @Override
    public void onClick(View v) {
        AboutusActivity.this.finish();

    }
}
